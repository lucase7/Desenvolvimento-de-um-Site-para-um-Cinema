# CinemaEmCasa — Projeto UNIBH

Projeto educacional de site para cinema (HTML + CSS + JS), **responsivo** e com **boas práticas de acessibilidade** (navegação por teclado, `aria-*`, contraste adequado e textos alternativos).

## Como executar localmente
1. Baixe este repositório (ou o arquivo `.zip`).
2. Abra o arquivo `index.html` no navegador (duplo-clique).

## Como publicar para sua professora

### Opção A — GitHub Pages
1. Crie um repositório no GitHub e envie os três arquivos (`index.html`, `styles.css`, `app.js`).
2. Vá em **Settings → Pages**.
3. Em **Build and deployment**, escolha **Deploy from a branch** e a branch `main`, pasta `/root`.
4. Salve. O GitHub irá gerar um link público após alguns minutos, algo como:
   `https://seu-usuario.github.io/CinemaEmCasa-UNIBH/`

### Opção B — Netlify (drag & drop)
1. Acesse https://app.netlify.com/drop
2. Arraste a pasta com os arquivos.
3. A plataforma gera um link público imediatamente.

## Acessibilidade
- **WCAG 2.2**: foco visível, navegação por teclado nas abas e no mapa de assentos, `aria-live` para feedback no formulário.
- Imagens com `alt`, botões com rótulos descritivos, contraste suficiente.

## Observações
- Os dados de filmes e sessões são **mock** (estáticos) e a compra é **simulada**.
- O bloco JSON-LD no `index.html` é **exemplo** de marcação para motores de busca.
