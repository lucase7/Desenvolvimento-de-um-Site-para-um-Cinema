/* =====================
 * DADOS MOCK & PREÇOS *
 * ===================== */
const BRL = new Intl.NumberFormat('pt-BR', { style:'currency', currency:'BRL' });
const PRECO_INTEIRA = 30.00;
const PRECO_MEIA = 15.00;

// Filmes
const filmes = [
  {
    id:'f1',
    titulo:'A Vida de Chuck',
    classificacao:'12',
    poster:'https://images.unsplash.com/photo-1517602302552-471fe67acf66?q=80&w=600&auto=format&fit=crop',
    destaque:true
  },
  {
    id:'f2',
    titulo:'Os Caras Malvados 2',
    classificacao:'L',
    poster:'https://images.unsplash.com/photo-1542204165-65bf26472b9b?q=80&w=600&auto=format&fit=crop',
    destaque:true
  },
  {
    id:'f3',
    titulo:'Invocação do Mal 4',
    classificacao:'16',
    poster:'https://images.unsplash.com/photo-1502136969935-8d071543e9cc?q=80&w=600&auto=format&fit=crop'
  },
  {
    id:'f4',
    titulo:'Quarteto Fantástico — Primeiros Passos',
    classificacao:'12',
    poster:'https://images.unsplash.com/photo-1517604931442-7e0c8ed2963c?q=80&w=600&auto=format&fit=crop'
  },
  {
    id:'f5',
    titulo:'Uma Sexta-feira Mais Louca Ainda!',
    classificacao:'10',
    poster:'https://images.unsplash.com/photo-1502139214985-d4af72f1f6d0?q=80&w=600&auto=format&fit=crop'
  }
];

// Datas (hoje + 6 dias)
const hoje = new Date();
const dias = [...Array(7)].map((_,i) => {
  const d = new Date(hoje); d.setDate(d.getDate()+i);
  return {
    iso: d.toISOString().split('T')[0],
    dia: d.getDate().toString().padStart(2,'0'),
    semana: d.toLocaleDateString('pt-BR', { weekday:'short' }).replace('.',''),
    label: d.toLocaleDateString('pt-BR', { weekday:'short', day:'2-digit', month:'2-digit' }).replace('.','')
  }
});

// Sessões (por data/filme)
// features: L = legendado, D = dublado, AD = audiodescrição, 3D, XD, D-BOX
const sessoes = {};

dias.forEach((d) => {
  sessoes[d.iso] = [
    {
      filme:'f1', sala:'Sala 3', horarios:[
        {hora:'14:10', formato:'2D', rec:['L']},
        {hora:'16:40', formato:'XD', rec:['L']},
        {hora:'19:10', formato:'XD', rec:['L','AD']},
      ]
    },
    {
      filme:'f2', sala:'Sala 7', horarios:[
        {hora:'13:30', formato:'3D', rec:['D']},
        {hora:'15:50', formato:'3D', rec:['D','AD']},
        {hora:'18:20', formato:'2D', rec:['D']},
      ]
    },
    {
      filme:'f3', sala:'Sala 1', horarios:[
        {hora:'17:00', formato:'2D', rec:['L','AD']},
        {hora:'20:10', formato:'D-BOX', rec:['L']},
        {hora:'22:30', formato:'XD', rec:['L']},
      ]
    },
    {
      filme:'f4', sala:'Sala 5', horarios:[
        {hora:'14:00', formato:'3D', rec:['L']},
        {hora:'18:00', formato:'XD', rec:['L']},
      ]
    },
    {
      filme:'f5', sala:'Sala 2', horarios:[
        {hora:'21:00', formato:'2D', rec:['L']},
      ]
    }
  ]
});

// Estado atual de compra
let estado = {
  dataISO: dias[0].iso,
  filmeId: null,
  sessao: null, // {hora, sala, formato, rec:[]}
  assentosSelecionados: [], // [{id:'A5', tipo:'inteira'|'meia'}]
  ocupados: new Set(['A4','A5','B7','C1','D2','E10','F3','G6']) // exemplo de ocupados
};

/* ===============
 * RENDERIZAÇÃO   *
 * =============== */
function el(tag, attrs={}, ...children){
  const $ = document.createElement(tag);
  Object.entries(attrs).forEach(([k,v])=>{
    if(v === false || v === null || v === undefined) return;
    if(k === 'class') $.className = v;
    else if(k.startsWith('on') && typeof v === 'function') $.addEventListener(k.substring(2), v);
    else if(k === 'dataset') Object.assign($.dataset, v);
    else $.setAttribute(k, v === true ? '' : v);
  });
  children.flat().forEach(c => $.append( c instanceof Node ? c : document.createTextNode(c) ));
  return $;
}

// Header nav: atualizar aria-current ao rolar
const links = [...document.querySelectorAll('[data-link]')];
function updateNav(){
  const hash = location.hash || '#inicio';
  links.forEach(a => a.setAttribute('aria-current', a.getAttribute('href')===hash ? 'page' : 'false'));
}
window.addEventListener('hashchange', updateNav);

// HERO posters
function renderHeroPosters(){
  const row = document.querySelector('.poster-row');
  row.innerHTML = '';
  filmes.filter(f => f.destaque).forEach(f=>{
    row.append(
      el('figure',{class:'poster'},
        el('img',{src:f.poster, alt:`Pôster do filme ${f.titulo}`, loading:'lazy'}),
        el('figcaption',{class:'help', style:'padding:.4rem .5rem'}, `${f.titulo} • ${f.classificacao}`)
      )
    );
  });
}

// Cards de filmes
function renderCardsFilmes(){
  const wrap = document.getElementById('cards-filmes');
  wrap.innerHTML = '';
  filmes.forEach(f=>{
    wrap.append(
      el('article', {class:'card', role:'listitem'},
        el('img', {src:f.poster, alt:`Pôster do filme ${f.titulo}`, loading:'lazy'}),
        el('div', {class:'card-body'},
          el('h3', {}, f.titulo),
          el('div', {class:'meta'},
            el('span', {class:'tag', title:'Classificação indicativa'}, `🔖 ${f.classificacao}`),
            el('span', {class:'tag', title:'Formato'}, '🎬 Cinema')
          )
        ),
        el('div', {class:'card-actions'},
          el('button', {class:'btn btn-sm', onClick:()=>irParaSessoes(f.id)}, 'Ver sessões'),
          el('a', {class:'btn btn-sm btn-ghost', href:'#compra', onClick:(e)=>{e.preventDefault(); compraRapida(f.id)}}, 'Comprar agora')
        )
      )
    );
  });
}

// Abas de datas
function renderTabsDatas(){
  const tabs = document.getElementById('date-tabs');
  tabs.innerHTML = '';
  dias.forEach((d, i)=>{
    tabs.append(
      el('button', {
          class:'date-tab',
          role:'tab',
          'aria-selected': estado.dataISO === d.iso ? 'true':'false',
          'aria-controls': `painel-${d.iso}`,
          onClick:()=>{estado.dataISO = d.iso; renderListaSessoes(); focusPrimeiroHorario()},
          onKeydown:(ev)=>navegacaoTabs(ev, i)
        },
        `${d.semana.toUpperCase()} ${d.dia}`
      )
    );
  });
}
function navegacaoTabs(ev, idx){
  const keys = ['ArrowLeft','ArrowRight','Home','End'];
  if(!keys.includes(ev.key)) return;
  ev.preventDefault();
  let target = idx;
  if(ev.key==='ArrowLeft') target = (idx-1+dias.length)%dias.length;
  if(ev.key==='ArrowRight') target = (idx+1)%dias.length;
  if(ev.key==='Home') target = 0;
  if(ev.key==='End') target = dias.length-1;
  estado.dataISO = dias[target].iso;
  renderTabsDatas(); renderListaSessoes();
  const tabBtn = document.querySelectorAll('.date-tab')[target];
  tabBtn.focus();
}

// Lista de sessões por data
function renderListaSessoes(){
  const lista = document.getElementById('lista-sessoes');
  lista.innerHTML = '';
  renderTabsDatas();

  const porData = sessoes[estado.dataISO] || [];
  porData.forEach(bloco=>{
    const filme = filmes.find(f=>f.id===bloco.filme);
    const linhaHorarios = el('div',{class:'times'},
      ...bloco.horarios.map(h =>
        el('button', {
          class:'time-btn',
          dataset:{format:h.formato},
          title:`${h.hora} • ${h.formato} • ${descricaoRecursos(h.rec)}`,
          onClick:()=>selecionarSessao(filme.id, {hora:h.hora, formato:h.formato, rec:h.rec, sala:bloco.sala})
        }, h.hora)
      )
    );

    lista.append(
      el('article',{class:'session-card'},
        el('div', {style:'display:flex; gap:.7rem; align-items:center; flex-wrap:wrap'},
          el('img',{src:filme.poster, alt:`Pôster ${filme.titulo}`, width:64, height:96, style:'border-radius:8px; object-fit:cover'}),
          el('div',{},
            el('strong',{}, filme.titulo),
            el('div', {class:'meta'},
              el('span',{class:'tag'}, `🔖 ${filme.classificacao}`),
              el('span',{class:'tag'}, `🛋️ ${bloco.sala}`),
              ...renderRecursosBadges()
            )
          )
        ),
        linhaHorarios
      )
    );

    function renderRecursosBadges(){
      return [
        el('span',{class:'tag', title:'Legenda'}, '🅻'),
        el('span',{class:'tag', title:'Dublado'}, '🅳'),
        el('span',{class:'tag', title:'Audiodescrição'}, '🅐')
      ];
    }
  });

  document.getElementById('sessao-escolhida').textContent =
    'Escolha um horário para habilitar o mapa de assentos.';
  document.getElementById('resumo-sessao').textContent = 'Nenhuma sessão selecionada.';
  limparSelecao();
}

function descricaoRecursos(rec){
  const mapa = {L:'Legenda', D:'Dublado', AD:'Audiodescrição'};
  return rec.map(r=>mapa[r]||r).join(', ');
}

// Selecionar sessão (preenche painel compra)
function selecionarSessao(filmeId, sessao){
  estado.filmeId = filmeId;
  estado.sessao = sessao;
  limparSelecao();
  renderSeatGrid();
  const f = filmes.find(x=>x.id===filmeId);
  const dataLabel = new Date(estado.dataISO).toLocaleDateString('pt-BR', {weekday:'long', day:'2-digit', month:'2-digit'});
  document.getElementById('sessao-escolhida').textContent =
    `Sessão selecionada: ${f.titulo} • ${dataLabel} • ${sessao.hora} • ${sessao.formato} • ${sessao.sala} • ${descricaoRecursos(sessao.rec)}.`;
  document.getElementById('resumo-sessao').textContent =
    `${f.titulo} — ${dataLabel} — ${sessao.hora} — ${sessao.formato} — ${sessao.sala}`;
  // rolar para compra
  location.hash = '#compra';
  // foco no primeiro assento disponível
  setTimeout(()=>focusPrimeiroAssento(),100);
}

function irParaSessoes(filmeId){
  location.hash = '#sessoes';
  // focar na sessão do filme
  setTimeout(()=>{
    const card = [...document.querySelectorAll('.session-card')].find(c=>c.querySelector('strong')?.textContent.includes(filmes.find(f=>f.id===filmeId).titulo));
    card?.querySelector('.time-btn')?.focus();
  },100);
}

function compraRapida(filmeId=null){
  // pega o primeiro filme e a primeira sessão do dia atual
  const dataISO = estado.dataISO;
  const lista = sessoes[dataISO];
  const bloco = filmeId ? lista.find(b=>b.filme===filmeId) : lista[0];
  const sess = bloco.horarios[0];
  selecionarSessao(bloco.filme, {hora:sess.hora, formato:sess.formato, rec:sess.rec, sala:bloco.sala});
}

// Grid de assentos (7x12)
function renderSeatGrid(){
  const grid = document.getElementById('seat-grid');
  grid.innerHTML = '';
  const rows = parseInt(grid.dataset.rows,10);
  const cols = parseInt(grid.dataset.cols,10);
  for(let r=0;r<rows;r++){
    for(let c=0;c<cols;c++){
      const label = `${String.fromCharCode(65+r)}${c+1}`;
      const ocupado = estado.ocupados.has(label);
      const btn = el('button', {
        class:'seat',
        role:'button',
        'aria-label': `Assento ${label} ${ocupado?'ocupado':'disponível'}`,
        'aria-pressed':'false',
        'data-state': ocupado?'ocupado':'livre',
        dataset: {row:r, col:c, label},
        disabled: ocupado,
        onClick:()=>toggleSeat(btn),
        onKeydown:(ev)=>moverComSetas(ev, btn)
      }, label);
      grid.append(btn);
    }
  }
}

function focusPrimeiroAssento(){
  const primeiro = [...document.querySelectorAll('.seat')].find(b=>!b.disabled);
  primeiro?.focus();
}

function focusPrimeiroHorario(){
  const primeiro = document.querySelector('.time-btn');
  primeiro?.focus();
}

function toggleSeat(btn){
  if(btn.disabled) return;
  const label = btn.dataset.label;
  const ja = estado.assentosSelecionados.find(a=>a.id===label);
  if(ja){
    estado.assentosSelecionados = estado.assentosSelecionados.filter(a=>a.id!==label);
    btn.setAttribute('aria-pressed','false');
    btn.style.background = '';
    announce(`Assento ${label} removido do carrinho.`);
  }else{
    estado.assentosSelecionados.push({id:label, tipo:'inteira'});
    btn.setAttribute('aria-pressed','true');
    announce(`Assento ${label} adicionado ao carrinho. Tipo: inteira.`);
  }
  renderCarrinho();
}

function moverComSetas(ev, btn){
  const keys = ['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','Home','End'];
  if(!keys.includes(ev.key)) return;
  ev.preventDefault();
  const r = parseInt(btn.dataset.row,10);
  const c = parseInt(btn.dataset.col,10);
  const grid = document.getElementById('seat-grid');
  const rows = parseInt(grid.dataset.rows,10);
  const cols = parseInt(grid.dataset.cols,10);
  let nr=r, nc=c;
  if(ev.key==='ArrowLeft') nc = Math.max(0,c-1);
  if(ev.key==='ArrowRight') nc = Math.min(cols-1,c+1);
  if(ev.key==='ArrowUp') nr = Math.max(0,r-1);
  if(ev.key==='ArrowDown') nr = Math.min(rows-1,r+1);
  if(ev.key==='Home'){ nr=r; nc=0; }
  if(ev.key==='End'){ nr=r; nc=cols-1; }
  const target = [...grid.children].find(b=>parseInt(b.dataset.row,10)===nr && parseInt(b.dataset.col,10)===nc);
  target?.focus();
}

// Carrinho
function renderCarrinho(){
  const carr = document.getElementById('carrinho');
  carr.innerHTML = '';
  if(estado.assentosSelecionados.length===0){
    carr.append( el('div', {class:'help'}, 'Nenhum assento selecionado.') );
  }else{
    estado.assentosSelecionados.forEach(item=>{
      carr.append(
        el('div',{class:'cart-item'},
          el('div',{}, `Assento ${item.id}`),
          el('div',{},
            el('label',{for:`tipo-${item.id}`, class:'sr-only'}, 'Tipo de ingresso'),
            el('select',{id:`tipo-${item.id}`, onChange:(e)=>{item.tipo = e.target.value; atualizarTotal();}},
              el('option',{value:'inteira', selected:item.tipo==='inteira'}, `Inteira — ${BRL.format(PRECO_INTEIRA)}`),
              el('option',{value:'meia', selected:item.tipo==='meia'}, `Meia — ${BRL.format(PRECO_MEIA)}`)
            )
          )
        )
      );
    });
  }
  atualizarTotal();
}

function atualizarTotal(){
  const total = estado.assentosSelecionados.reduce((acc, it)=>acc + (it.tipo==='meia'?PRECO_MEIA:PRECO_INTEIRA), 0);
  document.getElementById('total').textContent = `Total: ${BRL.format(total)}`;
}

function limparSelecao(){
  estado.assentosSelecionados = [];
  renderCarrinho();
  // reset grid pressed state
  document.querySelectorAll('.seat[aria-pressed="true"]').forEach(b=>b.setAttribute('aria-pressed','false'));
}

// Acessibilidade: região live
function announce(msg){
  const fb = document.getElementById('feedback');
  fb.textContent = msg;
}

/* ===============
 * FORM PGTTO     *
 * =============== */
const form = document.getElementById('form-pagamento');
form.addEventListener('submit', (e)=>{
  e.preventDefault();
  if(!estado.sessao){
    announce('Selecione um filme e um horário antes de pagar.');
    return;
  }
  if(estado.assentosSelecionados.length===0){
    announce('Selecione ao menos um assento.');
    return;
  }
  const required = [...form.querySelectorAll('[required]')];
  const invalid = required.filter(i=>!i.value.trim() || (i.pattern && !(new RegExp(i.pattern)).test(i.value.trim())));
  if(invalid.length){
    invalid[0].focus();
    announce('Existem campos inválidos. Verifique os dados do formulário.');
    return;
  }
  // Simulação de pagamento
  const pedido = Math.random().toString(36).slice(2,8).toUpperCase();
  announce(`Pagamento aprovado! Pedido #${pedido}. Ingressos enviados para o e-mail informado.`);
  // Reset (mantém sessão para permitir nova compra)
  limparSelecao();
  form.reset();
});

document.getElementById('limpar-selecao').addEventListener('click', limparSelecao);
document.getElementById('btn-compra-rapida').addEventListener('click', ()=>compraRapida());

/* ===============
 * INICIALIZA     *
 * =============== */
function init(){
  renderHeroPosters();
  renderCardsFilmes();
  renderTabsDatas();
  renderListaSessoes();
  updateNav();
}
init();
